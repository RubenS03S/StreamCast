let peer = null;
let localStream = null;
const video = document.getElementById('video');
const status = document.getElementById('status');
const micBtn = document.getElementById('micBtn');
let micOn = true;

function log(msg){status.textContent = msg;}

function startStream(){
  navigator.mediaDevices.getDisplayMedia({video:{width:3840,height:2160,frameRate:60},audio:true})
    .then(stream=>{
      localStream = stream;
      video.srcObject = stream;
      peer = new SimplePeer({initiator:true, trickle:false, stream});
      peer.on('signal', data=>{
        // generate 3‑digit code (simple random) and store signal in localStorage
        const code = Math.floor(100+Math.random()*900).toString();
        localStorage.setItem('signal_'+code, JSON.stringify(data));
        const url = location.origin+"/view.html?code="+code;
        const link = document.createElement('a');
        link.href = url; link.textContent = 'Lien du stream (copier)';
        document.body.appendChild(link);
        log('Stream démarré – code '+code);
      });
    })
    .catch(err=>log('Erreur écran : '+err));
}

function join(){
  const code = document.getElementById('codeInput').value.trim();
  if(!code){log('Entrez un code');return;}
  const signal = localStorage.getItem('signal_'+code);
  if(!signal){log('Code inconnu');return;}
  peer = new SimplePeer({initiator:false, trickle:false});
  peer.on('signal', data=>{
    // send back answer (store)
    localStorage.setItem('answer_'+code, JSON.stringify(data));
  });
  peer.on('stream', s=>{video.srcObject = s;});
  peer.signal(JSON.parse(signal));
  // wait for answer from streamer (poll every sec)
  const interval = setInterval(()=>{
    const ans = localStorage.getItem('answer_'+code);
    if(ans){peer.signal(JSON.parse(ans)); clearInterval(interval); log('Connecté');}
  },1000);
}

document.getElementById('startBtn').onclick = startStream;
document.getElementById('joinBtn').onclick = join;
micBtn.onclick = ()=>{
  if(!localStream) return;
  micOn = !micOn;
  localStream.getAudioTracks().forEach(t=>t.enabled = micOn);
  micBtn.textContent = micOn ? 'Couper micro' : 'Activer micro';
};
