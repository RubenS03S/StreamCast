# StreamCast

Application web ultra‑simple pour partager ton écran en direct (4K, 60 fps) avec un viewer sur iPad/iPhone.

## Comment l’utiliser
1. **Streamer (PC)** :
   - Ouvre `index.html` dans Chrome/Edge.
   - Clique **Démarrer le stream**. Un code à 3 chiffres est généré et un lien apparaît.
   - Copie le lien et envoie‑le à ton viewer.
2. **Viewer (iPad / iPhone)** :
   - Ouvre le lien dans Safari/Chrome.
   - La page se connecte automatiquement et montre ton écran.
   - Le micro est actif ; le streamer et le viewer peuvent parler.

## Fonctionnalités
- WebRTC + Simple‑Peer, pas de serveur dédié.
- Qualité 4K / 60 fps (retour à H.264 si le navigateur ne supporte pas VP9/AV1).
- Code à 3 chiffres = token d’accès privé.
- Mode plein écran / Picture‑in‑Picture.
- Fonctionne en tant que **PWA** : ajoute‑la à ton écran d’accueil iOS.

## Hébergement
Le zip est disponible ici : **https://github.com/ruben/StreamCast/releases/latest/download/StreamCast.zip**

## Déploiement (optionnel)
Tu peux héberger le dossier `StreamCast` sur Netlify, Vercel ou tout autre serveur static.
